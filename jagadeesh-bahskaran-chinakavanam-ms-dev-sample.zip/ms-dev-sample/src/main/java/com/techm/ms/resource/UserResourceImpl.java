package com.techm.ms.resource;

import javax.ws.rs.core.Link;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.techm.ms.model.Account;
import com.techm.ms.model.User;
import com.techm.ms.model.Userdto;
import com.techm.ms.model.representation.ResourceCollection;
import com.techm.ms.service.CreateUserService;
import javax.ws.rs.core.Link;


@Controller
public class UserResourceImpl implements UserResource {
	
	private static String baseUrl = "/creates";

	@Autowired
	CreateUserService createUserService;

	@Override
	public String createUser(Userdto user) {
		// TODO Auto-generated method stub
		
		String result = createUserService.createUser(user);
		if(result.equalsIgnoreCase("success")) {
			Link link = Link.fromUri(baseUrl).rel("self").build();		
		
		return result;
	}
		else
			return result;
		
		
	}
	
	
}
