package com.techm.ms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.techm.ms.model.Account;
import com.techm.ms.model.User;
import com.techm.ms.model.Userdto;

@Service("createService")
public class CreateUserServiceImpl implements CreateUserService {
	
	@Autowired
	AccountService accountService;
	
	private final String SUCCESS = "success";
	private final String FAILURE = "Unable to create. A Account with name already exist";

	@Override
	public String createUser(Userdto user) {
		
		if(null == accountService.findByName(user.getName()))
		
		{Account account = new Account();
		
		account.setId(user.getId());
		account.setName(user.getName());
		
		accountService.saveAccount(account);
		
		System.out.println("success");
		
		// TODO Auto-generated method stub
		return SUCCESS;
		
		}
		
		else
		{System.out.println(FAILURE);
			return FAILURE;
		}
	}

}
