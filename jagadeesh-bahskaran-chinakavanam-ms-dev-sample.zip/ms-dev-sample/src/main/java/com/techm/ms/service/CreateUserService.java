package com.techm.ms.service;


import com.techm.ms.model.Userdto;

public interface CreateUserService {

	String createUser(Userdto user);
	
}
